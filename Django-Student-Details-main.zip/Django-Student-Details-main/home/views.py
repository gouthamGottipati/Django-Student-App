from django.shortcuts import render, redirect
from .models import Student
from django.http import HttpResponse

def home(request):
    students = Student.objects.all()
    return render(request, 'home.html', {'students': students})

def add_student(request):
    if request.method == 'POST':
        name = request.POST['name']
        roll_number = request.POST['roll_number']
        email = request.POST['email']
        Student.objects.create(name=name, roll_number=roll_number, email=email)
        return redirect('home')
    return render(request, 'add_student.html')
